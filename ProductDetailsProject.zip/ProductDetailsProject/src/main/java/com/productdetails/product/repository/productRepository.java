package com.productdetails.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.productdetails.product.model.product;

public interface productRepository extends JpaRepository<product, Integer> {
	
	product findByProductId(Integer key);

}
