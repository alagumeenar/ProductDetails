package com.productdetails.product.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.productdetails.product.model.user;

public interface userRepository extends JpaRepository<user, Integer> {
	user findByUserId(Integer key);

}
