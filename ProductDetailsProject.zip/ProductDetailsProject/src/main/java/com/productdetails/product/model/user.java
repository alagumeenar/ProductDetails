package com.productdetails.product.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "user_list")
@Data

public class user {
	@Id
	@Column(name = "user_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer userId;  
	
	@Column(name = "user_uname")
    private String userUname;
	
	@Column(name = "user_password")
	private String userPassword;
	
	@Column(name = "user_name")
    private String userName;
	
	@Column(name = "user_mobileno")
    private String userMobileno;
	
	@Column(name = "user_mailID")
    private String userMailID;
	
	@Column(name = "user_address")
    private String userAddress;
}
