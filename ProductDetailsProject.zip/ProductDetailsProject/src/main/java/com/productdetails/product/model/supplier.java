package com.productdetails.product.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "supplier_list")
@Data
public class supplier {
	
	@Id
	@Column(name = "supplier_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer supplierId;
	
	@Column(name = "supplier_name")
	private String supplierName;
	
	@Column(name = "supplier_mobileno")
	private String supplierMobileno;
}
