package com.productdetails.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.productdetails.product.model.category;


public interface categoryRepository extends JpaRepository<category, Integer> {

	category findByCategoryId(Integer key);
}
