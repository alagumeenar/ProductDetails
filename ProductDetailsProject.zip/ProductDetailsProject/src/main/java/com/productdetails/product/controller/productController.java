package com.productdetails.product.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.productdetails.product.model.product;
import com.productdetails.product.repository.productRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class productController {

	@Autowired
	productRepository productRepo;

	@GetMapping("/products")
	public ResponseEntity<?> getAllProducts() {
		return ResponseEntity.ok(productRepo.findAll());
	}
	
	@GetMapping("/products/{id}")
	public ResponseEntity<?> getproductById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(productRepo.findById(id));
	}

	@PostMapping("/products")
	public ResponseEntity<?> createproduct(@RequestBody product product) {
		productRepo.save(product);
		return ResponseEntity.ok("Product has been saved!!!");
	}

	@PatchMapping("/products/{id}")
	public ResponseEntity<?> updateproduct(@PathVariable("id") int id, @RequestBody product product1) {
        product productData= productRepo.findByProductId(id);
       
        productData.setProductCategory(product1.getProductCategory());
        productData.setProductName(product1.getProductName());
        productData.setProductPrice(product1.getProductPrice());
        productData.setProductStock(product1.getProductStock());
        productData.setProductSupplier(product1.getProductSupplier());
        productData.setProductDesc(product1.getProductDesc());
        productRepo.save(productData);
        
			
		return ResponseEntity.ok("Product has been updated!!");
	
	}

	@DeleteMapping("/products/{id}")
	public ResponseEntity<?> deleteproduct(@PathVariable("id") Integer id) {
		productRepo.deleteById(id);
		return ResponseEntity.ok("Product has been deleted!!!");
	}

	@DeleteMapping("/products")
	public ResponseEntity<?> deleteAllproducts() {
		productRepo.deleteAll();
		return ResponseEntity.ok("All Products are deleted");
	}

//	@GetMapping("/products/name")
//	public ResponseEntity<List<product>> findByProductName() {
//		return null;
//	}
}
