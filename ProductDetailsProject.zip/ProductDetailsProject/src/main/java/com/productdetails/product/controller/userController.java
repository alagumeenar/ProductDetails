package com.productdetails.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productdetails.product.model.user;
import com.productdetails.product.repository.userRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class userController {

	@Autowired
	userRepository userRepo;
	
	@GetMapping("/users")
	public ResponseEntity<?> getAllUser() {
		return ResponseEntity.ok(userRepo.findAll());
	}
	
	@GetMapping("/users/{id}")
	public ResponseEntity<?> getuserById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(userRepo.findById(id));
	}

	@PostMapping("/users")
	public ResponseEntity<?> createuser(@RequestBody user user) {
		userRepo.save(user);
		return ResponseEntity.ok("User details has been saved!!!");
	}

	@PatchMapping("/users/{id}")
	public ResponseEntity<?> updateuser(@PathVariable("id") int id, @RequestBody user user1) {
		
        user userData= userRepo.findByUserId(id);
       
        userData.setUserId(user1.getUserId());
        userData.setUserUname(user1.getUserUname());
        userData.setUserPassword(user1.getUserPassword());
        userData.setUserName(user1.getUserName());
        userData.setUserMobileno(user1.getUserMobileno());
        userData.setUserMailID(user1.getUserMailID());
        userData.setUserAddress(user1.getUserAddress());
        
        userRepo.save(userData);
        	
		return ResponseEntity.ok("User details has been updated!!");
	
	}

	@DeleteMapping("/users/{id}")
	public ResponseEntity<?> deleteuser(@PathVariable("id") Integer id) {
		userRepo.deleteById(id);
		return ResponseEntity.ok("User details has been deleted!!!");
	}

	@DeleteMapping("/users")
	public ResponseEntity<?> deleteAllusers() {
		userRepo.deleteAll();
		return ResponseEntity.ok("All User details are deleted");
	}
}
