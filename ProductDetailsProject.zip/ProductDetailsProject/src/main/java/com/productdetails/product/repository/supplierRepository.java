package com.productdetails.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.productdetails.product.model.supplier;

public interface supplierRepository extends JpaRepository<supplier, Integer> {
	
	supplier findBySupplierId(Integer key);
}
