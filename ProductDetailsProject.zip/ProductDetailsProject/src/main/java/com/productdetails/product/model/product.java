package com.productdetails.product.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name= "products_list")
public class product {
	
	@Id
	@Column(name = "product_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	
	@Column(name = "product_name")
	private String productName;
	
	@Column(name = "productDesc")
	private String productDesc;
	
	@Column(name = "product_price")
	private Integer productPrice;
	
	@Column(name = "product_stock")
	private String productStock;
	
	@Column(name = "product_category")
	private String productCategory;
	
	@Column(name = "product_supplier")
	private String productSupplier;
	

}
