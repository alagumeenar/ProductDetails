package com.productdetails.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductDetailsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
